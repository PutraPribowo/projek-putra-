from django.conf.urls import url
from . import views

app_name = 'cart'
urlpatterns = [
    url(r'^$', views.cart_detail, name='cart_detail'),
    url(r'^(?P<product_id>[0-9]+)/cart_add/$', views.cart_add, name='cart_add'),
    url(r'^(?P<product_id>[0-9]+)/cart_remove/$', views.cart_remove, name='cart_remove'),
]
